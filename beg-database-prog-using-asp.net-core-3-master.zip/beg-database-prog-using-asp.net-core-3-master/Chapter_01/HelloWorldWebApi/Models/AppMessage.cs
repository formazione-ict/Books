﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelloWorldWebApi.Models
{
    public class AppMessage
    {
        public string Message { get; set; }
    }
}
