export class Country {
  countryID: number;
  name: string;
}
