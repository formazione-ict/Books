export class User {
  userName: string;
  password: string;
  email: string;
  fullName: string;
  birthDate: Date;
}
